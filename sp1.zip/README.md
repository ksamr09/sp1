# SUPORT BY SILENT TEAM BOT<br>
# BEBEK BOT TEAM & JUNSAN<br>
# SELFBOT 5asist 1 ajs <br>

# GUNAKAN DENGAN BIJAK <br>
# SEKEDAR BERBAGI ILMU BIAR BISA BERKEMBANG KETIKA LO SUDH DI ATAS JANGAN PERNAH SOMBONG DENGAN KARYA LO KARNA DULU LO BUKAN SIAPA-SIAPA.. <br>


# Cara install <br>

apt-get update -y <br>
pkg install python -y <br>
pkg install python2 -y <br>
apt-get install git -y <br>
apt-get install python3-pip -y <br> 
pip3 install rsa <br> 
pip3 install thrift==0.11.0 <br> 
pip3 install requests <br> 
pip3 install pytz <br> 
pip3 install bs4 <br> 
sudo pip3 install gtts <br> 
pip3 install googletrans <br> 
pip3 install humanfriendly<br> 
pip3 install goslate<br> 
pip3 install pafy<br> 
pip3 install wikipedia <br> 
pip3 install tweepy<br> 
pip3 install youtube_dl<br> 
git clone https://github.com/dhenza1415/SB7<br> 
ls<br> 
cd SBSILENT<br> 
ls<br> 
python3 dhenza7.py<br> 


Suport by: TBP [TEAM BOT PROTECT]<br> 
                BEBEK BOT TEAM & JUNSAN JUNIOR <br> 
          
Note : Jika ingin instal pke vps tinggal tambah sudo di depan command<br> 


 # Creator By TBP <br> 
## - Add My ID LINE : 〘 https://line.me/ti/p/~dhenz415 〙<br> 
##                   〘 https://line.me/ti/p/~teambotprotect 〙<br> 

